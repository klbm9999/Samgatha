<?php ob_start(); ?>
<html>


<head>
<title>Registered | Samgatha 2016</title>
<link rel="stylesheet" type="text/css" href="../css/basic.css" >
<link rel="icon" type="image/png" href="assets/samg_icon.png" sizes="96x96">

</head>

<body>

<?php require 'header.php'; ?>

<!-- Put your shit here  -->



<div style="color: #fff; position: absolute;top: 120px; left: 10pc;">
Change password link sent. Please confirm the email link sent to you.<br>
<br>GO Back home <a href="basic.php">here</a>

</div>





<!-- don't your shit after here  -->

<?php require 'footer.php'; ?>

</body>
<?php ob_end_flush(); ?>
</html>
