<?php 
	echo '
		<footer>

<div id="webops"><webops>webops@samgatha.org</webops></div>
<div id="link1"  class="footer_link" ><a  class="f_l" href="/about.php">About Us</a></div>
<div id="link2"  class="footer_link"><a  class="f_l" href="/feedback.php">Feedback</a></div>
<div id="link3"  class="footer_link"><a  class="f_l" href="/sponsors.php">Sponsors</a></div>
<div id="link4"  class="footer_link"><a  class="f_l" href="/hospi.php">Hospitality</a></div>
<div id="link5"  class="footer_link"><a  class="f_l" href="/makeinindia.php">Make in India</a></div>
<div id="link6"  ><a href="http://www.facebook.com/samgthaatiiitdm" target="_blank"><img src="/assets/fb.svg"  width="30px" height="30px"></a></div>
<div id="link7"  ><a href="http://twitter.com/samgatha" target="_blank" ><img src="/assets/twit.svg"  width="30px" height="30px"></a></div>
<div id="link8"  ><a href="http://www.youtube.com/user/SamgathaIIITDM/featured" target="_blank"><img src="/assets/youtube.svg"  width="30px" height="30px"></a></div>

</footer>
	';
 ?>