<?php session_start();
  if (!isset($_SESSION['validlogin'])) {
    $_SESSION['validlogin'] = 0;
  }
 ?>
<html>

<head>
<title>Sponsors | Samgatha 2016</title>
<link rel="stylesheet" type="text/css" href="../css/basic.css" >
<link rel="stylesheet" href="../css/nights.css">
<link rel="icon" type="image/png" href="assets/samg_icon.png" sizes="96x96">

</head>

<body>

<?php require 'header.php'; ?>

<!-- Put your shit here  -->



<div class="content">

  



</div>


<!-- don't your shit after here  -->

<?php require 'footer.php'; ?>
</body>

</html>