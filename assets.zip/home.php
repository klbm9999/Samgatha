<?php
header('Location:/markup/basic.html');
?>