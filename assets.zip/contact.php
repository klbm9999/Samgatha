<?php session_start();
  if (!isset($_SESSION['validlogin'])) {
    $_SESSION['validlogin'] = 0;
  }
 ?>
<html>

<head>
<title>Reach Us | Samgatha 2016</title>
<link rel="stylesheet" type="text/css" href="../css/basic.css" >
<link rel="stylesheet" type="text/css" href="../css/contact.css" >
<link rel="icon" type="image/png" href="assets/samg_icon.png" sizes="96x96">


</head>

<body>
<?php require 'header.php'; ?>

<!-- Put your shit here  -->

<div id="content">


<div class="box" id="b1">
   <div class="dep">Organiser</div>
   <div class="avatar_container"><img class="avatar" src="../assets/mask.png"></div>
   <div id="b1_name" class="name">Rineetha Charles</div>
   <div class="contact">Contact - 8148844964</div>   

</div>

<div class="box" id="b2">
      <div class="dep">Organiser</div>

   <div class="avatar_container"><img class="avatar" src="../assets/mask.png"></div>
   <div class="name">Sowjanya B.</div>
   <div class="contact"> Contact - 8608902235</div>   

</div>

<div class="box" id="b3">
   <div class="dep">Organiser</div>

   <div class="avatar_container"><img class="avatar" src="../assets/mask.png"></div>
   <div class="name">CKP Sai Gopal</div>
   <div class="contact"> Contact - 9941414390</div>   

</div>


<div class="box" id="b4">
   <div class="dep">Organiser</div>

   <div class="avatar_container"><img class="avatar" src="../assets/mask.png"></div>
   <div class="name">Nithin Shamshuddin</div>
   <div class="contact">Contact- 9941319117</div>   

</div>


<div class="box" id="b5">
   <div class="dep">Publicity Core</div>

   <div class="avatar_container"><img class="avatar" src="../assets/mask.png"></div>
   <div class="name">Nirmal A.</div>
   <div class="contact">Contact - 9791376553</div>   

</div>


<div class="box" id="b6">
     <div class="dep">Sponsors Core</div>
   <div class="avatar_container"><img class="avatar" src="../assets/mask.png"></div>
   <div class="name">Seshuram </div>
   <div class="contact"> Contact - 7401484864</div>   

</div>

<div class="box" id="b7">
 <div class="dep">Sponsors Core</div>
   <div class="avatar_container"><img class="avatar" src="../assets/mask.png"></div>
   <div class="name">Sudheer S.</div>
   <div class="contact"> Contact - 9444407940</div>   

</div>


<div class="box" id="b8">
 <div class="dep">Web Ops Team</div>
   <div class="avatar_container"><img class="avatar" src="../assets/mask.png"></div>
   <div class="name">K.L. Bhanu Moorthy</div>
   <div class="contact"> Contact - 9710493230</div>   

</div>


<div class="box" id="b9">
  <div class="dep">Web Ops Team</div>
 
   <div class="avatar_container"><img class="avatar" src="../assets/mask.png"></div>
   <div class="name">Vedant Bassi</div>
   <div class="contact"> Contact - 9500094537</div>   

</div>


<div class="box" id="b10">
<div class="dep">Q.M.S. Core</div>
 
   <div class="avatar_container"><img class="avatar" src="../assets/mask.png"></div>
   <div class="name">Avinash Reddy</div>
   <div class="contact"> Contact - 9841277922</div>   

</div>

<div class="box" id="b11">
<div class="dep">Q.M.S. Core</div>
 
   <div class="avatar_container"><img class="avatar" src="../assets/mask.png"></div>
   <div class="name">Rahul S. </div>
   <div class="contact"> Contact - 9492153439 </div>   

</div>

<div class="box" id="b12">
<div class="dep">Hospitality</div>
 
   <div class="avatar_container"><img class="avatar" src="../assets/mask.png"></div>
   <div class="name">R. Hemanth </div>
   <div class="contact"> Contact - 9710080520 </div>   

</div>

<div class="box" id="b13">
<div class="dep">Hospitality</div>
 
   <div class="avatar_container"><img class="avatar" src="../assets/mask.png"></div>
   <div class="name">Sowjanya V. </div>
   <div class="contact"> Contact - 7338707666 </div>   

</div>

<div class="box" id="b14">
<div class="dep">Gen. Affairs</div>
 
   <div class="avatar_container"><img class="avatar" src="../assets/mask.png"></div>
   <div class="name">G. Harish </div>
   <div class="contact"> Contact - 9941313466 </div>   

</div>

<div class="box" id="b15">
<div class="dep">Gen. Affairs</div>
 
   <div class="avatar_container"><img class="avatar" src="../assets/mask.png"></div>
   <div class="name">Suma S. </div>
   <div class="contact"> Contact - 9551542145 </div>   

</div>


</div>

<!-- don't your shit after here  -->

<?php require 'footer.php'; ?>

</body>

</html>